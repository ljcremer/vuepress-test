---
lang: en-US
title: Home
description: Description 2
---
## We are Tesla Texas
# <Badge type="tip" text="!!!" vertical="top" /> Giga Texas Onboarding Access Guide
\
Welcome to the onboarding and access guide. In this guide you will be able to find all the information pertaining to requirements & regulations to gain access to Giga Texas.

<Badge type="tip" text="1" vertical="middle" /> Choose a topic from the sidebar menu on the left >
<Badge type="tip" text="2" vertical="middle" /> Use a search bar to search for a specific words or phrase

