---
lang: en-US
title: Contacts
description: Description 2
---

# Contacts

|Procurement                |EHS                          |ACCESS CONTROL                         |
|----------------|-------------------------------|-----------------------------|
|Construction - Jessica Munoz|Jake Lowney            |Tammy Martini           |
|Manufacturing CAPEX - Tara Lucier         |Thomas Braham          |Kim Tran           |
|Indirect - Athina Martinez |Laura Harting||
|Production Parts -        |           |          |
|Facilities- Jessica Munoz        |            |            |












