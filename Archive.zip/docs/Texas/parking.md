---
lang: en-US
title: Parking Passes
description: Description 2
---
# Parking Passes
## Yellow Pass
Yellow parking passes are only for approved contractors who need to use company vehicles to access the site.
## Display Pass
The pass must be displayed on the dash of the vehicle to allow efficient verification by access control.
