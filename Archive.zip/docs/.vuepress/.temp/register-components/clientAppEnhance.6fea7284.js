import { defineAsyncComponent } from 'vue'

export default ({ app }) => {
  app.component("TroopAlgolia", defineAsyncComponent(() => import("/Users/missz/Development/vuepress-test/docs/.vuepress/components/TroopAlgolia.vue")))
}
