<template><h1 id="contractors-vendors-and-service-provider-procedures" tabindex="-1"><a class="header-anchor" href="#contractors-vendors-and-service-provider-procedures" aria-hidden="true">#</a> Contractors Vendors and Service Provider Procedures</h1>
<p>All companies performing a service or conducting work that requires site access must complete the following requirements prior to accessing the site. It is important to recognize that requirements are broken into two categories, <strong>Procurement</strong> and <strong>EHS</strong>. These requirements are managed by separate departments at Tesla. Please contact your Tesla Responsible Person (TRP) for questions relating to your status.</p>
<h2 id="procurement-requirements" tabindex="-1"><a class="header-anchor" href="#procurement-requirements" aria-hidden="true">#</a> Procurement Requirements</h2>
<h3 id="construction-contractors" tabindex="-1"><a class="header-anchor" href="#construction-contractors" aria-hidden="true">#</a> Construction Contractors</h3>
<blockquote>
<p>eComply Profile must be approved and visible to Security and Access Control (See instructions on page 3)</p>
</blockquote>
<h3 id="manufacturing-contractors" tabindex="-1"><a class="header-anchor" href="#manufacturing-contractors" aria-hidden="true">#</a> Manufacturing Contractors</h3>
<blockquote>
<p>Primary supplier should have a valid purchase order. GSM team will ensure the following documentation is on file in Warp</p>
</blockquote>
<table>
<thead>
<tr>
<th>Construction Contractors</th>
<th>Manufacturing Contractors</th>
</tr>
</thead>
<tbody>
<tr>
<td>Signed Non-Disclosure Agreement (NDA)</td>
<td>Signed Non-Disclosure Agreement (NDA)</td>
</tr>
<tr>
<td>Current Certificate of Insurance</td>
<td>Current certificate of Insurance (COI)</td>
</tr>
<tr>
<td>OCIP Certificate of Insurance</td>
<td>Signed General Terms &amp; Conditions</td>
</tr>
<tr>
<td>Conflict of Interest (COI)</td>
<td></td>
</tr>
<tr>
<td>Pre-qualification Questionnaire</td>
<td></td>
</tr>
</tbody>
</table>
<ul>
<li>
<Badge type="warning" text="Note" vertical="middle" />  The CRP and TRP will be notified of approval. Upon notification, the contracted company is approved to access the site and perform site walk. 
</li>
</ul>
<h2 id="ehs-requirements" tabindex="-1"><a class="header-anchor" href="#ehs-requirements" aria-hidden="true">#</a> EHS Requirements</h2>
<h3 id="each-company-must" tabindex="-1"><a class="header-anchor" href="#each-company-must" aria-hidden="true">#</a> <strong>Each company must:</strong></h3>
<p><br>
\</p>
<Badge type="tip" text="1" vertical="middle" /> Provide Copy of Safety Manual to TRP
\
<Badge type="tip" text="2" vertical="middle" /> 2.Complete Pre-Project EHS Questionnaire prior to Orientation and Badging.
<table>
<thead>
<tr>
<th>Complete Form</th>
<th>Submit</th>
<th>Review</th>
</tr>
</thead>
<tbody>
<tr>
<td>Complete this form: Pre-Project EHS Questionnaire</td>
<td>Submit to link above 72 hours prior to access</td>
<td>Questionnaires will be reviewed by Tesla Contractor EHS</td>
</tr>
</tbody>
</table>
<h3 id="each-employee-must" tabindex="-1"><a class="header-anchor" href="#each-employee-must" aria-hidden="true">#</a> <strong>Each employee must:</strong></h3>
<Badge type="tip" text="1" vertical="middle" /> Hold current OSHA 10-hour (Employees) or 30-hour (Supervisors) Card
<Badge type="tip" text="2" vertical="middle" /> Complete Orientation
<p><strong>Orientation Requirements</strong>
\</p>
<ol>
<li>
<p>Safety orientation is required prior to being allowed to access site and start work.</p>
</li>
<li>
<p>Orientation is completed online through: https://teslamotors.inclassnow.com/sign-up</p>
</li>
<li>
<p>Each employee will be promoted to create a profile and select the location work will be preformed.</p>
</li>
<li>
<p>Orientation is site specific. Make sure you select the right location: GIGA TEXAS</p>
</li>
<li>
<p>Orientation consists of Tesla Orientation, Contractor Orientation, COVID-19 Questionnaire and Tobacco Free Workplace acknowledgement (40 minutes)</p>
</li>
<li>
<p>Badges will be issued after orientation has been completed.</p>
</li>
</ol>
</template>
