export const data = {
  "key": "v-393c4a87",
  "path": "/Texas/ecomply.html",
  "title": "eComply",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "eComply",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "Logging In",
      "slug": "logging-in",
      "children": []
    },
    {
      "level": 2,
      "title": "Account Setup",
      "slug": "account-setup",
      "children": []
    },
    {
      "level": 2,
      "title": "PreQualification Questionnaire",
      "slug": "prequalification-questionnaire",
      "children": []
    },
    {
      "level": 2,
      "title": "Documentation",
      "slug": "documentation",
      "children": []
    }
  ],
  "filePathRelative": "Texas/ecomply.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
