<template><h2 id="we-are-tesla-texas" tabindex="-1"><a class="header-anchor" href="#we-are-tesla-texas" aria-hidden="true">#</a> We are Tesla Texas</h2>
<h1 id="giga-texas-onboarding-access-guide" tabindex="-1"><a class="header-anchor" href="#giga-texas-onboarding-access-guide" aria-hidden="true">#</a> <Badge type="tip" text="!!!" vertical="top" /> Giga Texas Onboarding Access Guide</h1>
<p><br>
Welcome to the onboarding and access guide. In this guide you will be able to find all the information pertaining to requirements &amp; regulations to gain access to Giga Texas.</p>
<Badge type="tip" text="1" vertical="middle" /> Choose a topic from the sidebar menu on the left >
<Badge type="tip" text="2" vertical="middle" /> Use a search bar to search for a specific words or phrase
</template>
