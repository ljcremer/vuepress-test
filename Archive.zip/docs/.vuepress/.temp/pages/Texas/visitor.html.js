export const data = {
  "key": "v-2884108c",
  "path": "/Texas/visitor.html",
  "title": "Visitor Procedure",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Visitor Procedure",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [],
  "filePathRelative": "Texas/visitor.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
