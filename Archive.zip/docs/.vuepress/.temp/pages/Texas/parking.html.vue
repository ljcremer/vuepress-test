<template><h1 id="parking-passes" tabindex="-1"><a class="header-anchor" href="#parking-passes" aria-hidden="true">#</a> Parking Passes</h1>
<h2 id="yellow-pass" tabindex="-1"><a class="header-anchor" href="#yellow-pass" aria-hidden="true">#</a> Yellow Pass</h2>
<p>Yellow parking passes are only for approved contractors who need to use company vehicles to access the site.</p>
<h2 id="display-pass" tabindex="-1"><a class="header-anchor" href="#display-pass" aria-hidden="true">#</a> Display Pass</h2>
<p>The pass must be displayed on the dash of the vehicle to allow efficient verification by access control.</p>
</template>
