<template><h1 id="ecomply" tabindex="-1"><a class="header-anchor" href="#ecomply" aria-hidden="true">#</a> eComply</h1>
<ul>
<li></li>
</ul>
<h2 id="logging-in" tabindex="-1"><a class="header-anchor" href="#logging-in" aria-hidden="true">#</a> Logging In</h2>
<p>You will need to go to the following website to complete your companies prequalification: <a href="https://tesla.ecomply.us/" target="_blank" rel="noopener noreferrer">https://tesla.ecomply.us/)<OutboundLink/></a></p>
<p>Once on the portal page, go to create account and use the below agency code on the first tab to begin entering your company's information.</p>
<div class="custom-container tip"><p class="custom-container-title">TIP</p>
<Badge type="tip" text=" Access Code:TeslaTX" vertical="middle" />
</div>
<h2 id="account-setup" tabindex="-1"><a class="header-anchor" href="#account-setup" aria-hidden="true">#</a> Account Setup</h2>
<p>Complete all required fields as Tesla will use this information in verifying that your company is cleared to work with Tesla.</p>
<p>There are multiple tabs in account setup, ensure that all sections are completed.</p>
<p>When selecting Business Type, please choose one of the below options:</p>
<h2 id="prequalification-questionnaire" tabindex="-1"><a class="header-anchor" href="#prequalification-questionnaire" aria-hidden="true">#</a> PreQualification Questionnaire</h2>
<p><em>Required for all construction work and long-term vendors</em></p>
<p>This information will be utilized by Tesla to ensure your company meets needed qualifications to work at Tesla facilities.
To enter this information go to the Prequalification Module on the Activities Tab.</p>
<div class="custom-container tip"><p class="custom-container-title">TIP</p>
<p>Verify all necessary fields have been completed prior to submitting, incomplete questionnaires will not be accepted.</p>
</div>
<h2 id="documentation" tabindex="-1"><a class="header-anchor" href="#documentation" aria-hidden="true">#</a> Documentation</h2>
<p>You will need to upload the below documents into the prequalification form or contractor documents tab. These must be renewed as they expire, you will receive a notification 30 days prior to expiration.</p>
<table>
<thead>
<tr>
<th>Info Required</th>
</tr>
</thead>
<tbody>
<tr>
<td>Signed Non-Disclosure Agreement (NDA)</td>
</tr>
<tr>
<td>Current Certificate of Insurance</td>
</tr>
<tr>
<td>OCIP Certificate of Insurance</td>
</tr>
<tr>
<td>Conflict of Interest (COI)</td>
</tr>
<tr>
<td>Prequalification Questionnaire</td>
</tr>
</tbody>
</table>
</template>
