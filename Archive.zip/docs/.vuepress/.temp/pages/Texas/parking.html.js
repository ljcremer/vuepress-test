export const data = {
  "key": "v-e75512a0",
  "path": "/Texas/parking.html",
  "title": "Parking Passes",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Parking Passes",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "Yellow Pass",
      "slug": "yellow-pass",
      "children": []
    },
    {
      "level": 2,
      "title": "Display Pass",
      "slug": "display-pass",
      "children": []
    }
  ],
  "filePathRelative": "Texas/parking.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
