<template><h1 id="access-request-and-badging" tabindex="-1"><a class="header-anchor" href="#access-request-and-badging" aria-hidden="true">#</a> Access Request and Badging</h1>
<p>After the Procurement and EHS requirements have been completed, the contract company may coordinate badging for employees.</p>
<p>Access requests should be submitted <strong>48 hours</strong> in advance of person arriving on site.</p>
<h2 id="_1-provide-a-list-of-employees-with-the-following-information-to-the-applicable-trp" tabindex="-1"><a class="header-anchor" href="#_1-provide-a-list-of-employees-with-the-following-information-to-the-applicable-trp" aria-hidden="true">#</a> 1. Provide a list of employees with the following information to the applicable TRP:</h2>
<table>
<thead>
<tr>
<th>Info Required</th>
</tr>
</thead>
<tbody>
<tr>
<td>Company Name</td>
</tr>
<tr>
<td>Legal name of personnel requesting access</td>
</tr>
<tr>
<td>(Must match Government issued ID)</td>
</tr>
<tr>
<td>Phone Number</td>
</tr>
<tr>
<td>Length of time access needed</td>
</tr>
<tr>
<td>Expected arrival time at the gate</td>
</tr>
</tbody>
</table>
<h2 id="_2-the-trp-will-then-forward-the-access-request-to-gftxaccesscontrol-com" tabindex="-1"><a class="header-anchor" href="#_2-the-trp-will-then-forward-the-access-request-to-gftxaccesscontrol-com" aria-hidden="true">#</a> 2. The TRP will then forward the access request to GFTXaccesscontrol.com</h2>
<h2 id="_3-access-control-will-be-sent-via-email-that-the-request-has-been-granted" tabindex="-1"><a class="header-anchor" href="#_3-access-control-will-be-sent-via-email-that-the-request-has-been-granted" aria-hidden="true">#</a> 3. Access control will be sent via email that the request has been granted.</h2>
<div class="custom-container tip"><p class="custom-container-title">TIP</p>
<p>Individuals are required to present government issued ID matching the name provided in order to receive a badge</p>
</div>
<div class="custom-container tip"><p class="custom-container-title">TIP</p>
<p>Temporary badges will be issued for a maximum 60 days.</p>
</div>
<div class="custom-container tip"><p class="custom-container-title">TIP</p>
<p>Photo badges will be issued as required according to site access plan. Photo will be taken on site, and badges can be printed immediately.</p>
</div>
</template>
