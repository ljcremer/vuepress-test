export const data = {
  "key": "v-9540930a",
  "path": "/Texas/questions.html",
  "title": "Questions",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Questions",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [],
  "filePathRelative": "Texas/questions.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
