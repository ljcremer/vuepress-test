export const data = {
  "key": "v-cc58d092",
  "path": "/Texas/contacts.html",
  "title": "Contacts",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Contacts",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [],
  "filePathRelative": "Texas/contacts.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
