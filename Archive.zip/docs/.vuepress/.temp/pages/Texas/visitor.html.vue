<template><h1 id="visitor-procedure" tabindex="-1"><a class="header-anchor" href="#visitor-procedure" aria-hidden="true">#</a> Visitor Procedure</h1>
<p><strong>Media, Government Officials or Guests attending pre-bid meetings, preliminary site visits, prequalification meetings, or chaperoned events.</strong></p>
<div class="custom-container warning"><p class="custom-container-title">WARNING</p>
<p>Submit requests 48 hours in advance</p>
</div>
<p>If a person is not performing work, and will strictly be on site for a short-term visit, they will need to sign a visitor non-disclosure agreement and get clearance at the gate. The Tesla employee requesting access will email the following information to GFTXaccesscontrol@tesla.com;</p>
<table>
<thead>
<tr>
<th>Info Required</th>
</tr>
</thead>
<tbody>
<tr>
<td>Company Name</td>
</tr>
<tr>
<td>Legal name of personnel requesting access</td>
</tr>
<tr>
<td>(Must match Government issued ID)</td>
</tr>
<tr>
<td>Length of time access needed</td>
</tr>
<tr>
<td>Expected arrival time at the gate</td>
</tr>
</tbody>
</table>
<ul>
<li>
<Badge type="warning" text="Note" vertical="middle" />  Personnel must present a government issued ID to verify identity at the gate and check in.
</li>
<li>
<Badge type="warning" text="Note" vertical="middle" /> ID's must be visible as visitors tour the facility</li>
</ul>
</template>
