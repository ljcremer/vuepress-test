<template><h1 id="testing-vue-component" tabindex="-1"><a class="header-anchor" href="#testing-vue-component" aria-hidden="true">#</a> Testing vue component</h1>
<p>TroopAlgolia
<code>&lt;TroopAlgolia/&gt;</code> <TroopAlgolia/></p>
<h1 id="getting-started-222" tabindex="-1"><a class="header-anchor" href="#getting-started-222" aria-hidden="true">#</a> Getting started 222</h1>
<iframe  width="800" height="450" src="https://www.figma.com/embed?embed_host=share&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FAWm4bulHTVb9z6zRe2O05D%2FTroop-Design-System-Kraft%3Fnode-id%3D0%253A1%26hide-ui%3D1"></iframe>
</template>
