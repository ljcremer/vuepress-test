export const data = {
  "key": "v-12216586",
  "path": "/Texas/access.html",
  "title": "Access Request & Badging",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Access Request & Badging",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "1. Provide a list of employees with the following information to the applicable TRP:",
      "slug": "_1-provide-a-list-of-employees-with-the-following-information-to-the-applicable-trp",
      "children": []
    },
    {
      "level": 2,
      "title": "2. The TRP will then forward the access request to GFTXaccesscontrol.com",
      "slug": "_2-the-trp-will-then-forward-the-access-request-to-gftxaccesscontrol-com",
      "children": []
    },
    {
      "level": 2,
      "title": "3. Access control will be sent via email that the request has been granted.",
      "slug": "_3-access-control-will-be-sent-via-email-that-the-request-has-been-granted",
      "children": []
    }
  ],
  "filePathRelative": "Texas/access.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
