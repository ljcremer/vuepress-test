export const data = {
  "key": "v-e3e1e94a",
  "path": "/Texas/Page.html",
  "title": "Page test",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Page test",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "Create files and folders",
      "slug": "create-files-and-folders",
      "children": []
    },
    {
      "level": 2,
      "title": "Heading 2",
      "slug": "heading-2",
      "children": [
        {
          "level": 3,
          "title": "Heading 3",
          "slug": "heading-3",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "Hello VuePress3",
      "slug": "hello-vuepress3",
      "children": [
        {
          "level": 3,
          "title": "Hello VuePress3",
          "slug": "hello-vuepress3-1",
          "children": []
        },
        {
          "level": 3,
          "title": "Hello VuePress4",
          "slug": "hello-vuepress4",
          "children": []
        }
      ]
    }
  ],
  "filePathRelative": "Texas/Page.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
