export const data = {
  "key": "v-8b4d081c",
  "path": "/Texas/Temp/testing-this.html",
  "title": "testing this",
  "lang": "en",
  "frontmatter": {
    "lang": "en",
    "title": "testing this",
    "description": ""
  },
  "excerpt": "",
  "headers": [],
  "filePathRelative": "Texas/Temp/testing-this.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
