<template><h1 id="contacts" tabindex="-1"><a class="header-anchor" href="#contacts" aria-hidden="true">#</a> Contacts</h1>
<table>
<thead>
<tr>
<th>Procurement</th>
<th>EHS</th>
<th>ACCESS CONTROL</th>
</tr>
</thead>
<tbody>
<tr>
<td>Construction - Jessica Munoz</td>
<td>Jake Lowney</td>
<td>Tammy Martini</td>
</tr>
<tr>
<td>Manufacturing CAPEX - Tara Lucier</td>
<td>Thomas Braham</td>
<td>Kim Tran</td>
</tr>
<tr>
<td>Indirect - Athina Martinez</td>
<td>Laura Harting</td>
<td></td>
</tr>
<tr>
<td>Production Parts -</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Facilities- Jessica Munoz</td>
<td></td>
<td></td>
</tr>
</tbody>
</table>
</template>
