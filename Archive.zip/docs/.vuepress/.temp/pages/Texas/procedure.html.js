export const data = {
  "key": "v-08130e96",
  "path": "/Texas/procedure.html",
  "title": "Procedures",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Procedures",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "Procurement Requirements",
      "slug": "procurement-requirements",
      "children": [
        {
          "level": 3,
          "title": "Construction Contractors",
          "slug": "construction-contractors",
          "children": []
        },
        {
          "level": 3,
          "title": "Manufacturing Contractors",
          "slug": "manufacturing-contractors",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "EHS Requirements",
      "slug": "ehs-requirements",
      "children": [
        {
          "level": 3,
          "title": "Each company must:",
          "slug": "each-company-must",
          "children": []
        },
        {
          "level": 3,
          "title": "Each employee must:",
          "slug": "each-employee-must",
          "children": []
        }
      ]
    }
  ],
  "filePathRelative": "Texas/procedure.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
