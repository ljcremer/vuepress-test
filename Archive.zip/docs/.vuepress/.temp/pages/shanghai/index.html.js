export const data = {
  "key": "v-cd0bacaa",
  "path": "/shanghai/",
  "title": "Readme.md",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Readme.md",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [],
  "filePathRelative": "shanghai/README.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
