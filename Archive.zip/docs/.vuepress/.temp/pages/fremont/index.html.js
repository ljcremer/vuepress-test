export const data = {
  "key": "v-7b74c6c7",
  "path": "/fremont/",
  "title": "Readme.md",
  "lang": "en-US",
  "frontmatter": {
    "lang": "en-US",
    "title": "Readme.md",
    "description": "Description 2"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "We are Tesla Fremont",
      "slug": "we-are-tesla-fremont",
      "children": []
    }
  ],
  "filePathRelative": "fremont/README.md",
  "git": {
    "updatedTime": null,
    "contributors": []
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
