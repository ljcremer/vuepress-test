import clientAppEnhance0 from '/Users/missz/Development/vuepress-test/node_modules/@vuepress/theme-default/lib/client/clientAppEnhance.js'
import clientAppEnhance1 from '/Users/missz/Development/vuepress-test/node_modules/@vuepress/plugin-medium-zoom/lib/client/clientAppEnhance.js'
import clientAppEnhance2 from '/Users/missz/Development/vuepress-test/node_modules/@vuepress/plugin-theme-data/lib/client/clientAppEnhance.js'
import clientAppEnhance3 from '/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/register-components/clientAppEnhance.6fea7284.js'

export const clientAppEnhances = [
  clientAppEnhance0,
  clientAppEnhance1,
  clientAppEnhance2,
  clientAppEnhance3,
]
