import clientAppRootComponent0 from '/Users/missz/Development/vuepress-test/node_modules/@vuepress/plugin-back-to-top/lib/client/components/BackToTop.js'

export const clientAppRootComponents = [
  clientAppRootComponent0,
]
