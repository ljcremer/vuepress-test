import { defineAsyncComponent } from 'vue'

export const pagesComponents = {
  // path: /
  "v-8daa1a0e": defineAsyncComponent(() => import(/* webpackChunkName: "v-8daa1a0e" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/index.html.vue")),
  // path: /Texas/Page.html
  "v-e3e1e94a": defineAsyncComponent(() => import(/* webpackChunkName: "v-e3e1e94a" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/Page.html.vue")),
  // path: /Texas/
  "v-5ebb750f": defineAsyncComponent(() => import(/* webpackChunkName: "v-5ebb750f" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/index.html.vue")),
  // path: /Texas/access.html
  "v-12216586": defineAsyncComponent(() => import(/* webpackChunkName: "v-12216586" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/access.html.vue")),
  // path: /Texas/contacts.html
  "v-cc58d092": defineAsyncComponent(() => import(/* webpackChunkName: "v-cc58d092" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/contacts.html.vue")),
  // path: /Texas/ecomply.html
  "v-393c4a87": defineAsyncComponent(() => import(/* webpackChunkName: "v-393c4a87" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/ecomply.html.vue")),
  // path: /Texas/parking.html
  "v-e75512a0": defineAsyncComponent(() => import(/* webpackChunkName: "v-e75512a0" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/parking.html.vue")),
  // path: /Texas/procedure.html
  "v-08130e96": defineAsyncComponent(() => import(/* webpackChunkName: "v-08130e96" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/procedure.html.vue")),
  // path: /Texas/questions.html
  "v-9540930a": defineAsyncComponent(() => import(/* webpackChunkName: "v-9540930a" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/questions.html.vue")),
  // path: /Texas/visitor.html
  "v-2884108c": defineAsyncComponent(() => import(/* webpackChunkName: "v-2884108c" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/visitor.html.vue")),
  // path: /fremont/
  "v-7b74c6c7": defineAsyncComponent(() => import(/* webpackChunkName: "v-7b74c6c7" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/fremont/index.html.vue")),
  // path: /shanghai/
  "v-cd0bacaa": defineAsyncComponent(() => import(/* webpackChunkName: "v-cd0bacaa" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/shanghai/index.html.vue")),
  // path: /Texas/Temp/testing-this.html
  "v-8b4d081c": defineAsyncComponent(() => import(/* webpackChunkName: "v-8b4d081c" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/Temp/testing-this.html.vue")),
  // path: /404.html
  "v-3706649a": defineAsyncComponent(() => import(/* webpackChunkName: "v-3706649a" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/404.html.vue")),
}
