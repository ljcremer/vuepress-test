import { Vuepress } from '@vuepress/client/lib/components/Vuepress'

const routeItems = [
  ["v-8daa1a0e","/","Title 1",["/index.html","/README.md"]],
  ["v-e3e1e94a","/Texas/Page.html","Page test",["/Texas/Page","/Texas/Page.md"]],
  ["v-5ebb750f","/Texas/","Home",["/Texas/index.html","/Texas/README.md"]],
  ["v-12216586","/Texas/access.html","Access Request & Badging",["/Texas/access","/Texas/access.md"]],
  ["v-cc58d092","/Texas/contacts.html","Contacts",["/Texas/contacts","/Texas/contacts.md"]],
  ["v-393c4a87","/Texas/ecomply.html","eComply",["/Texas/ecomply","/Texas/ecomply.md"]],
  ["v-e75512a0","/Texas/parking.html","Parking Passes",["/Texas/parking","/Texas/parking.md"]],
  ["v-08130e96","/Texas/procedure.html","Procedures",["/Texas/procedure","/Texas/procedure.md"]],
  ["v-9540930a","/Texas/questions.html","Questions",["/Texas/questions","/Texas/questions.md"]],
  ["v-2884108c","/Texas/visitor.html","Visitor Procedure",["/Texas/visitor","/Texas/visitor.md"]],
  ["v-7b74c6c7","/fremont/","Readme.md",["/fremont/index.html","/fremont/README.md"]],
  ["v-cd0bacaa","/shanghai/","Readme.md",["/shanghai/index.html","/shanghai/README.md"]],
  ["v-8b4d081c","/Texas/Temp/testing-this.html","testing this",["/Texas/Temp/testing-this","/Texas/Temp/testing-this.md"]],
  ["v-3706649a","/404.html","",["/404"]],
]

export const pagesRoutes = routeItems.reduce(
  (result, [name, path, title, redirects]) => {
    result.push(
      {
        name,
        path,
        component: Vuepress,
        meta: { title },
      },
      ...redirects.map((item) => ({
        path: item,
        redirect: path,
      }))
    )
    return result
  },
  [
    {
      name: "404",
      path: "/:catchAll(.*)",
      component: Vuepress,
    }
  ]
)
