export const pagesData = {
  // path: /
  "v-8daa1a0e": () => import(/* webpackChunkName: "v-8daa1a0e" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/index.html.js").then(({ data }) => data),
  // path: /Texas/Page.html
  "v-e3e1e94a": () => import(/* webpackChunkName: "v-e3e1e94a" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/Page.html.js").then(({ data }) => data),
  // path: /Texas/
  "v-5ebb750f": () => import(/* webpackChunkName: "v-5ebb750f" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/index.html.js").then(({ data }) => data),
  // path: /Texas/access.html
  "v-12216586": () => import(/* webpackChunkName: "v-12216586" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/access.html.js").then(({ data }) => data),
  // path: /Texas/contacts.html
  "v-cc58d092": () => import(/* webpackChunkName: "v-cc58d092" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/contacts.html.js").then(({ data }) => data),
  // path: /Texas/ecomply.html
  "v-393c4a87": () => import(/* webpackChunkName: "v-393c4a87" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/ecomply.html.js").then(({ data }) => data),
  // path: /Texas/parking.html
  "v-e75512a0": () => import(/* webpackChunkName: "v-e75512a0" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/parking.html.js").then(({ data }) => data),
  // path: /Texas/procedure.html
  "v-08130e96": () => import(/* webpackChunkName: "v-08130e96" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/procedure.html.js").then(({ data }) => data),
  // path: /Texas/questions.html
  "v-9540930a": () => import(/* webpackChunkName: "v-9540930a" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/questions.html.js").then(({ data }) => data),
  // path: /Texas/visitor.html
  "v-2884108c": () => import(/* webpackChunkName: "v-2884108c" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/visitor.html.js").then(({ data }) => data),
  // path: /fremont/
  "v-7b74c6c7": () => import(/* webpackChunkName: "v-7b74c6c7" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/fremont/index.html.js").then(({ data }) => data),
  // path: /shanghai/
  "v-cd0bacaa": () => import(/* webpackChunkName: "v-cd0bacaa" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/shanghai/index.html.js").then(({ data }) => data),
  // path: /Texas/Temp/testing-this.html
  "v-8b4d081c": () => import(/* webpackChunkName: "v-8b4d081c" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/Texas/Temp/testing-this.html.js").then(({ data }) => data),
  // path: /404.html
  "v-3706649a": () => import(/* webpackChunkName: "v-3706649a" */"/Users/missz/Development/vuepress-test/docs/.vuepress/.temp/pages/404.html.js").then(({ data }) => data),
}
