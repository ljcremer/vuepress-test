import type { SidebarConfig } from "@vuepress/theme-default";

export const en: SidebarConfig = {
  "/texas/": [
    {
      isGroup: true,
      text: "Texas",
      children: [
        "/texas/procedure.md",
         "/texas/access.md", 
         "/texas/parking.md", 
         "/texas/visitor.md", 
         "/texas/contacts.md", 
         "/texas/ecomply.md", 
         "/texas/questions.md"]
    },
  ],
};
